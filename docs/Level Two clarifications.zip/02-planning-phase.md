# 02 - Фаза планирования

## Назначение

В фазе планирования игрок составляет план дня, размещая корабли с едой и интервенциями в слоты временной шкалы. Качество плана определяет успех симуляции.

---

## Ключевые правила UI (согласованы)

### Отображение слотов
- **По одному**: видно только 1 пустой слот (следующий доступный)
- **Прогрессивно**: заполнил слот → появляется следующий
- **По рядам**: когда ряд заполнен → показывается следующий ряд
- **Заполненные видны**: уже размещённые корабли остаются на экране

### Drag-and-drop UX
- **Красивый drag**: визуальный feedback при поднятии корабля
- **Hover на слот**: подсветка при наведении на доступный слот
- **Валидация**: нельзя бросить если корабль не помещается

### Кнопка "Simulate"
- **Неактивна** пока не набрано минимальное количество углеводов
- **Активна** когда min carbs достигнут

---

## UI Layout

### Начальное состояние
```
Morning Row 1: [ пустой ]     ← только 1 слот виден
```

### После размещения кораблей
```
Morning Row 1: [ 🍎 ][ 🥪🥪 ]    ← ряд заполнен
Morning Row 2: [ пустой ]        ← появляется следующий ряд
```

### Полный layout (для справки)
```
┌─────────────────────────────────────────────────────────────────┐
│                         HEADER                                   │
│  ┌─────────┐  ┌────────────────────────┐  ┌──────────────────┐  │
│  │ BG: 147 │  │ Carbs: ████░░ 67/100   │  │ [Simulate ▶]    │  │
│  └─────────┘  └────────────────────────┘  └──────────────────┘  │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │ MORNING                                                      ││
│  │  ┌─────┐ ┌─────┐ ┌─────┐                                    ││
│  │  │  🥣 │ │     │ │     │  ◄── Row 1 (unloading first)       ││
│  │  └─────┘ └─────┘ └─────┘                                    ││
│  │  ┌─────┐ ┌─────┐ ┌─────┐                                    ││
│  │  │     │ │     │ │     │  ◄── Row 2 (waiting)               ││
│  │  └─────┘ └─────┘ └─────┘                                    ││
│  └─────────────────────────────────────────────────────────────┘│
│                                                                  │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │ DAY                                                          ││
│  │  ┌─────┐ ┌───────────┐ ┌─────┐                              ││
│  │  │  💊 │ │    🥪     │ │     │  ◄── Medium ship = 2 slots   ││
│  │  └─────┘ └───────────┘ └─────┘                              ││
│  │  ┌─────────────────┐ ┌─────┐ ┌─────┐                        ││
│  │  │      🍝         │ │     │ │     │  ◄── Large ship = 3    ││
│  │  └─────────────────┘ └─────┘ └─────┘                        ││
│  └─────────────────────────────────────────────────────────────┘│
│                                                                  │
│  ┌─────────────────────────────────────────────────────────────┐│
│  │ EVENING                                                      ││
│  │  ┌─────┐ ┌─────┐ ┌─────┐                                    ││
│  │  │     │ │     │ │     │                                    ││
│  │  └─────┘ └─────┘ └─────┘                                    ││
│  │  ┌─────┐ ┌─────┐ ┌─────┐                                    ││
│  │  │     │ │     │ │     │                                    ││
│  │  └─────┘ └─────┘ └─────┘                                    ││
│  └─────────────────────────────────────────────────────────────┘│
│                                                                  │
├─────────────────────────────────────────────────────────────────┤
│                      SHIP INVENTORY                              │
│  ┌──────────────┬──────────────┐                                │
│  │ [Food]       │ Interventions │  ◄── Tabs                     │
│  └──────────────┴──────────────┘                                │
│  ┌─────┐ ┌─────┐ ┌───────────┐ ┌─────────────────┐              │
│  │ 🍬  │ │ 🍎  │ │    🥪     │ │       🍝        │              │
│  │ S   │ │ S   │ │     M     │ │        L        │              │
│  │ 25g │ │ 15g │ │    35g    │ │       45g       │              │
│  └─────┘ └─────┘ └───────────┘ └─────────────────┘              │
└─────────────────────────────────────────────────────────────────┘
```

---

## Структура данных планирования

### Слот

```typescript
interface SlotPosition {
  segment: DaySegment;  // 'Morning' | 'Day' | 'Evening'
  row: 0 | 1;           // 0 = верхний (разгрузочный), 1 = нижний
  index: 0 | 1 | 2;     // позиция в ряду
}

// Глобальный ID слота для удобства
type SlotId = `${DaySegment}-${0|1}-${0|1|2}`;
// Примеры: "Morning-0-0", "Day-1-2", "Evening-0-1"
```

### Размещённый корабль

```typescript
interface PlacedShip {
  instanceId: string;      // Уникальный ID размещения (uuid)
  shipId: string;          // ID корабля из конфига
  segment: DaySegment;
  row: 0 | 1;
  startSlot: 0 | 1 | 2;    // Начальный слот
  // endSlot вычисляется: startSlot + ship.slotsRequired - 1
}
```

### Состояние планирования

```typescript
interface PlanningState {
  placedShips: PlacedShip[];

  // Computed
  totalCarbs: number;          // Сумма carbs всех размещённых food ships
  isValid: boolean;            // totalCarbs >= minCarbs
  occupiedSlots: Set<SlotId>;  // Занятые слоты
}
```

---

## Правила размещения кораблей

### 1. Занятие слотов по размеру

| Size | Slots | Пример |
|------|-------|--------|
| S    | 1     | `[🍎][ ][ ]` |
| M    | 2     | `[🥪🥪][ ]` |
| L    | 3     | `[🍝🍝🍝]` |

### 2. Корабль не может выходить за пределы ряда

```
✅ Допустимо:
Row: [🍝🍝🍝]     (L корабль в слотах 0-2)
Row: [ ][🥪🥪]    (M корабль в слотах 1-2)

❌ Недопустимо:
Row: [ ][ ][🍝... (L корабль начинается в слоте 2 - не помещается)
```

### 3. Корабль не может пересекать другие корабли

```
❌ Недопустимо:
Row: [🍎][🥪🥪]   (Если 🍎 уже стоит в слоте 0, нельзя поставить M в слот 0 или 1)
```

### 4. Один корабль — один ряд

Корабль не может занимать слоты в разных рядах или сегментах.

---

## Drag and Drop

### Библиотека: @dnd-kit

Используем `@dnd-kit` потому что:
- Хорошая поддержка accessibility
- Гибкая кастомизация
- Работает с React 18
- Поддержка touch events

### Draggable: ShipCard

```typescript
// components/planning/ShipCard.tsx
import { useDraggable } from '@dnd-kit/core';

interface ShipCardProps {
  ship: Ship;
  isPlaced?: boolean;
  instanceId?: string;  // Если уже размещён
}

function ShipCard({ ship, isPlaced, instanceId }: ShipCardProps) {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({
    id: instanceId ?? `inventory-${ship.id}`,
    data: {
      ship,
      isPlaced,
      instanceId,
    },
  });

  return (
    <div
      ref={setNodeRef}
      className={`ship-card ship-size-${ship.size}`}
      style={{ transform: CSS.Transform.toString(transform) }}
      {...listeners}
      {...attributes}
    >
      <span className="ship-emoji">{ship.emoji}</span>
      <span className="ship-name">{ship.name}</span>
      <span className="ship-carbs">{ship.load}g</span>
    </div>
  );
}
```

### Droppable: Slot

```typescript
// components/planning/Slot.tsx
import { useDroppable } from '@dnd-kit/core';

interface SlotProps {
  slotId: SlotId;
  isOccupied: boolean;
  canDrop: boolean;  // Подсветка при drag over
  children?: React.ReactNode;
}

function Slot({ slotId, isOccupied, canDrop, children }: SlotProps) {
  const { isOver, setNodeRef } = useDroppable({
    id: slotId,
    disabled: isOccupied,
  });

  return (
    <div
      ref={setNodeRef}
      className={cn(
        'slot',
        isOccupied && 'slot-occupied',
        isOver && canDrop && 'slot-highlight',
        isOver && !canDrop && 'slot-invalid'
      )}
    >
      {children}
    </div>
  );
}
```

### DndContext

```typescript
// components/planning/PlanningPhase.tsx
import { DndContext, DragEndEvent, DragOverEvent } from '@dnd-kit/core';

function PlanningPhase() {
  const { placedShips, placeShip, removeShip } = useGameStore();
  const [activeShip, setActiveShip] = useState<Ship | null>(null);
  const [validDropSlots, setValidDropSlots] = useState<Set<SlotId>>(new Set());

  function handleDragStart(event: DragStartEvent) {
    const ship = event.active.data.current?.ship;
    setActiveShip(ship);
    // Вычислить валидные слоты для этого корабля
    setValidDropSlots(calculateValidSlots(ship, placedShips));
  }

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;

    if (over && validDropSlots.has(over.id as SlotId)) {
      const ship = active.data.current?.ship;
      const wasPlaced = active.data.current?.isPlaced;
      const oldInstanceId = active.data.current?.instanceId;

      // Если перемещаем уже размещённый корабль — сначала удаляем
      if (wasPlaced && oldInstanceId) {
        removeShip(oldInstanceId);
      }

      // Парсим slotId
      const [segment, row, slot] = (over.id as string).split('-');
      placeShip(ship, segment as DaySegment, Number(row), Number(slot));
    }

    setActiveShip(null);
    setValidDropSlots(new Set());
  }

  return (
    <DndContext onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
      <PlanningHeader />
      <DayTimeline />
      <ShipInventory />
      <DragOverlay>
        {activeShip && <ShipCard ship={activeShip} />}
      </DragOverlay>
    </DndContext>
  );
}
```

---

## Валидация плана

### Минимальное требование по углеводам

```typescript
// core/planning/PlanValidator.ts

interface ValidationResult {
  isValid: boolean;
  totalCarbs: number;
  minCarbs: number;
  maxCarbs: number;
  errors: string[];
  warnings: string[];
}

function validatePlan(
  placedShips: PlacedShip[],
  shipConfigs: Record<string, Ship>,
  levelConfig: LevelConfig
): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Считаем углеводы
  let totalCarbs = 0;
  for (const placed of placedShips) {
    const ship = shipConfigs[placed.shipId];
    if (ship.loadType === 'Glucose') {
      totalCarbs += ship.load;
    }
  }

  // Проверяем минимум
  if (totalCarbs < levelConfig.minCarbs) {
    errors.push(`Недостаточно углеводов: ${totalCarbs}/${levelConfig.minCarbs}`);
  }

  // Проверяем максимум (warning, не error)
  if (totalCarbs > levelConfig.maxCarbs) {
    warnings.push(`Много углеводов: ${totalCarbs}/${levelConfig.maxCarbs}. Риск перегрузки.`);
  }

  return {
    isValid: errors.length === 0,
    totalCarbs,
    minCarbs: levelConfig.minCarbs,
    maxCarbs: levelConfig.maxCarbs,
    errors,
    warnings,
  };
}
```

### UI индикация

```
Carbs Meter:
├── Серая зона: [0, minCarbs) — недостаточно
├── Зелёная зона: [minCarbs, maxCarbs] — оптимально
└── Красная зона: (maxCarbs, ∞) — перебор

[░░░░░░████████░░░░░░░░░░░░░░]
      ^min      ^current  ^max
```

---

## Inventory (список кораблей)

### Структура

```typescript
interface InventoryState {
  activeTab: 'Food' | 'Interventions';
  ships: Ship[];  // Фильтруются по activeTab
}
```

### Tabs

- **Food**: корабли с `loadType === 'Glucose'`
- **Interventions**: корабли с `loadType === 'Treatment'`

### Доступность кораблей

В прототипе все корабли доступны в неограниченном количестве.

В будущем можно добавить:
- Ограничение по количеству
- Разблокировка по прогрессии
- Стоимость (валюта)

---

## UX подсказки

### При drag-over

1. **Валидные слоты** — подсвечиваются зелёным
2. **Невалидные слоты** — подсвечиваются красным (уже занят, не помещается)
3. **Рекомендуемые слоты** — для интервенций можно подсвечивать оптимальные позиции

### Подсказки по кораблям

При hover на корабль в inventory:
```
┌─────────────────────────┐
│ 🥣 Oatmeal              │
│ Size: L (3 slots)       │
│ Carbs: 40g              │
│ Unload time: 3 hours    │
│ Slow glucose release    │
└─────────────────────────┘
```

---

## Компоненты

### PlanningPhase.tsx
- Основной контейнер фазы
- DndContext wrapper
- Layout: Header + Timeline + Inventory

### PlanningHeader.tsx
- Текущий BG (из предыдущего дня или начальный)
- Carbs meter (progress bar)
- Simulate button (disabled если !isValid)

### DayTimeline.tsx
- Контейнер для 3 сегментов
- Скролл если не помещается

### Segment.tsx
- Заголовок (Morning/Day/Evening)
- SlotGrid

### SlotGrid.tsx
- 2 ряда × 3 слота
- Row labels (optional)

### Slot.tsx
- Droppable зона
- Визуализация занятости
- Корабль если размещён

### ShipCard.tsx
- Draggable элемент
- Emoji + название + характеристики
- Размер зависит от ship.size

### ShipInventory.tsx
- Tabs: Food / Interventions
- Grid/List кораблей
- Scrollable

---

## Решённые вопросы

1. ~~**Удаление корабля**~~ → **Drag обратно** в inventory (поле с едой)

2. ~~**Копирование плана**~~ → **Не нужно**

3. **Подсказки AI**: Показывать рекомендуемое размещение для новичков? → Отложено

4. ~~**Мобильный UX**~~ → **Mobile First** — делаем адаптацию сразу

---

## Открытые вопросы

1. **Интервенции в планировании**: Metformin и Exercise — это тоже "корабли" которые размещаются в слоты? Или отдельный механизм?

2. **Ограничение количества еды**: В прототипе еда неограничена. Но можно ли разместить один и тот же тип еды несколько раз? (Например, 3 яблока в разные слоты)

3. **Валидация при drop**: Если корабль L (3 слота) пытаются бросить в слот 1 или 2 ряда — показывать ошибку или просто не давать бросить?

4. **Mobile drag**: На мобильных touch drag может быть неудобен. Нужен ли альтернативный способ (tap to select → tap to place)?

---

## TODO

- [ ] Определить точные размеры слотов в пикселях
- [ ] Дизайн Ship карточек
- [ ] Анимации drag-and-drop
- [ ] Звуки при размещении
